module.exports = {

	twitter: {
  	consumer_key: 'mBlpHEpUcd3tjAFYWoil7vtfN',
		consumer_secret: 'd3P0QPFxB5gA9XfjhgvpHEedXOQjVXJYze8JmZVd49Gh6ah8bk',
		access_token: '3276809839-9Qdx5lDSNPZJXmWVaKOO6BmQpj8lGpotd7onFI0',
		access_token_secret: 'jjGM5DNjDIujHmEhuKFpFrPtScpwNt2aDnG2Yb5fgLHKA'
	}

};